#!/usr/bin/env python3
"""
内存操作测试用例 - 执行各种内存操作
用于测试动态检测系统能否捕获内存行为
"""

import gc
import sys
import struct

print("[开始] 内存操作测试")

# 1. 获取对象内存大小
print("[1] sys.getsizeof - 查询对象大小")
data = "A" * 1000
print(f"  -> String size: {sys.getsizeof(data)} bytes")
test_list = [1] * 1000
print(f"  -> List size: {sys.getsizeof(test_list)} bytes")

# 2. GC 检查
print("[2] gc - 垃圾回收检查")
stats = gc.get_stats()
print(f"  -> GC generations: {len(stats)}")
count = gc.get_count()
print(f"  -> GC count: {count}")

# 3. 获取所有对象
print("[3] gc.get_objects - 对象枚举")
all_objects = gc.get_objects()
print(f"  -> Total objects: {len(all_objects)}")

# 4. struct 内存打包
print("[4] struct.pack - 内存打包")
packed = struct.pack('<I', 0xdeadbeef)
print(f"  -> Packed: {packed.hex()}")
large_buffer = struct.pack('<' + 'B'*100, *range(100))
print(f"  -> Large buffer: {len(large_buffer)} bytes")

# 5. ctypes 内存操作
print("[5] ctypes - 底层内存操作")
try:
    from ctypes import *
    buffer = create_string_buffer(100)
    print(f"  -> Buffer created: {len(buffer)} bytes")
    memset(buffer, 0, len(buffer))
    print(f"  -> Buffer zeroed")
    ptr = pointer(c_int(42))
    print(f"  -> Pointer created")
except ImportError:
    print(f"  -> ctypes not available")
except Exception as e:
    print(f"  -> Error: {e}")

# 6. 堆喷射模拟
print("[6] 堆喷射模拟")
spray_blocks = []
block_size = 1024
num_blocks = 100
for i in range(num_blocks):
    spray_blocks.append(b"\x90" * block_size)  # NOP sled
total = sum(len(b) for b in spray_blocks)
print(f"  -> Allocated: {total} bytes in {num_blocks} blocks")
spray_blocks.clear()
gc.collect()

# 7. shellcode 模式
print("[7] shellcode 模式检测")
shellcode_patterns = [
    b"\x90\x90\x90\x90",      # NOP sled
    b"\xcc\xcc\xcc\xcc",      # INT3
    b"\x31\xc0",              # XOR EAX, EAX
    b"\xeb\xfe",              # JMP $
]
for i, pattern in enumerate(shellcode_patterns):
    print(f"  -> Pattern {i+1}: {pattern.hex()}")

# 8. memoryview 操作
print("[8] memoryview - 直接内存访问")
data = bytearray(100)
mv = memoryview(data)
print(f"  -> Created: {len(mv)} bytes")
mv[0:10] = b'\x90' * 10
print(f"  -> Modified memory")

# 9. 内省检查
print("[9] 内省 - 对象属性检查")
class TestClass:
    def __init__(self):
        self.secret = "sensitive_data"

obj = TestClass()
print(f"  -> __dict__ keys: {list(obj.__dict__.keys())}")
print(f"  -> dir() count: {len(dir(obj))}")
print(f"  -> vars(): {vars(obj)}")

print("[完成] 内存操作测试")
