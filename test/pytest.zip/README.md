# 动态检测测试用例

用于测试动态分析系统是否能捕获各种恶意行为的测试用例集。

## 测试文件

| 文件 | 测试内容 |
|------|---------|
| `test_syscall.py` | 系统调用：subprocess, os.system, 进程执行 |
| `test_network.py` | 网络活动：HTTP/HTTPS, DNS, Socket, 端口扫描 |
| `test_file.py` | 文件操作：敏感文件读取, 目录遍历, 文件写入 |
| `test_memory.py` | 内存操作：对象查询, GC, struct, ctypes, 堆喷射 |
| `test_combined.py` | 组合攻击：数据窃取, 侦察, C2通信, 勒索软件 |

## 使用方法

```bash
# 运行所有测试
python run_all.py

# 运行单个测试
python test_syscall.py
python test_network.py
python test_file.py
python test_memory.py
python test_combined.py
```

## 检测点参考

### test_syscall.py
- `subprocess.run()`
- `os.system()`
- `subprocess.Popen()`
- `subprocess.call()`
- `subprocess.check_output()`

### test_network.py
- `urllib.request.urlopen()` - HTTP/HTTPS
- `socket.gethostbyname()` - DNS查询
- `socket.connect()` - TCP连接
- 端口扫描行为
- `requests.get/post()` (如果可用)

### test_file.py
- `open()` - 敏感文件读取
- 目录遍历模式
- `os.listdir()` - 目录枚举
- `Path.glob()` - 递归搜索
- 文件写入

### test_memory.py
- `sys.getsizeof()` - 内存查询
- `gc.get_stats/count/objects()` - 对象枚举
- `struct.pack()` - 内存打包
- `ctypes` - 底层内存操作
- 堆喷射模式
- shellcode模式
- `memoryview` - 直接内存访问

### test_combined.py
- 数据窃取攻击链
- 系统侦察攻击链
- 命令注入模式
- 持久化行为
- C2通信模拟
- 勒索软件行为
- 加密货币挖矿
