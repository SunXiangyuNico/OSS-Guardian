#!/usr/bin/env python3
"""
文件操作测试用例 - 执行各种文件操作
用于测试动态检测系统能否捕获文件行为
"""

import os
import glob
from pathlib import Path

print("[开始] 文件操作测试")

# 1. 读取敏感文件（Windows）
print("[1] 尝试读取敏感文件")
sensitive_files = [
    "C:\\Windows\\System32\\drivers\\etc\\hosts",
    "C:\\Windows\\System32\\config\\SAM",
    "C:\\boot.ini",
]
for path in sensitive_files:
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(100)
            print(f"  -> Read: {path} ({len(content)} bytes)")
    except PermissionError:
        print(f"  -> Permission Denied: {path}")
    except FileNotFoundError:
        print(f"  -> Not Found: {path}")
    except Exception as e:
        print(f"  -> Error: {path} - {e}")

# 2. 目录遍历尝试
print("[2] 目录遍历模式")
traversal_patterns = [
    "../../../etc/passwd",
    "..\\..\\..\\Windows\\System32\\config\\SAM",
]
for pattern in traversal_patterns:
    print(f"  -> Traversal: {pattern}")

# 3. 列出目录内容
print("[3] os.listdir - 用户目录")
user_dir = os.path.expanduser("~")
try:
    items = os.listdir(user_dir)
    print(f"  -> Found {len(items)} items in {user_dir}")
except Exception as e:
    print(f"  -> Error: {e}")

# 4. 递归搜索
print("[4] glob 递归搜索")
patterns = ["**/*.py", "**/*.txt", "**/*.exe"]
for pattern in patterns:
    try:
        files = list(Path(os.getcwd()).glob(pattern))[:10]
        print(f"  -> glob '{pattern}': {len(files)} files (showing first 10)")
    except Exception as e:
        print(f"  -> Error: {e}")

# 5. 写入文件
print("[5] 文件写入")
temp_dir = os.path.expanduser("~/Desktop")
write_files = [
    ("test_executable.bat", "@echo off\nrem malicious\n"),
    ("test_script.ps1", "Write-Host 'test'\n"),
    ("test_data.json", '{"key": "value"}\n'),
]
for filename, content in write_files:
    try:
        filepath = os.path.join(temp_dir, filename)
        with open(filepath, 'w') as f:
            f.write(content)
        print(f"  -> Written: {filepath}")
        # 清理
        os.remove(filepath)
    except Exception as e:
        print(f"  -> Error: {e}")

# 6. 获取文件信息
print("[6] os.path 操作")
test_path = __file__
print(f"  -> exists: {os.path.exists(test_path)}")
print(f"  -> isfile: {os.path.isfile(test_path)}")
print(f"  -> getsize: {os.path.getsize(test_path)} bytes")

print("[完成] 文件操作测试")
