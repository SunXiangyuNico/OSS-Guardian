#!/usr/bin/env python3
"""
运行所有测试用例
"""

import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent

TESTS = [
    "test_syscall.py",
    "test_network.py",
    "test_file.py",
    "test_memory.py",
    "test_combined.py",
]

def main():
    print("="*60)
    print("动态检测测试用例 - 运行所有测试")
    print("="*60)
    print()

    for test in TESTS:
        test_path = SCRIPT_DIR / test
        if not test_path.exists():
            print(f"[跳过] {test} - 文件不存在")
            continue

        print(f"\n{'='*60}")
        print(f"运行: {test}")
        print(f"{'='*60}")

        result = subprocess.run(
            [sys.executable, str(test_path)],
            cwd=SCRIPT_DIR,
            text=True
        )

        if result.returncode != 0:
            print(f"\n[错误] {test} 退出码: {result.returncode}")

    print("\n" + "="*60)
    print("所有测试完成")
    print("="*60)

if __name__ == "__main__":
    main()
