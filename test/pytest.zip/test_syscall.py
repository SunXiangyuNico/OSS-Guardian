#!/usr/bin/env python3
"""
系统调用测试用例 - 执行各种系统命令
用于测试动态检测系统能否捕获进程执行行为
"""

import os
import sys
import subprocess

print("[开始] 系统调用测试")

# 1. subprocess.run
print("[1] subprocess.run - whoami")
result = subprocess.run(["whoami"], capture_output=True, text=True)
print(f"  -> {result.stdout.strip()}")

# 2. os.system
print("[2] os.system - hostname")
os.system("hostname")

# 3. subprocess.Popen
print("[3] subprocess.Popen - dir")
proc = subprocess.Popen(["cmd", "/c", "dir"], stdout=subprocess.PIPE, text=True)
proc.communicate()

# 4. subprocess.call
print("[4] subprocess.call - echo")
subprocess.call(["echo", "test"], shell=False)

# 5. subprocess.check_output
print("[5] subprocess.check_output - 获取环境变量")
output = subprocess.check_output(["echo", "%USERNAME%"], shell=True)
print(f"  -> {output.decode().strip()}")

print("[完成] 系统调用测试")
